// Em um novo arquivo: Tela1Fragment.kt
package com.example.memoriaviva2.ui // Ou o pacote apropriado

import androidx.fragment.app.Fragment
import com.example.memoriaviva2.R // Certifique-se que R está importado

class Tela1 : Fragment(R.layout.um) {
    // ... Lógica do Tela1Fragment aqui ...
}